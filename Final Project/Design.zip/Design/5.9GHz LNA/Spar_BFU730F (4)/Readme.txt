Files included in this Zip file are containing de-embedded s-parameters; de-embedded and smoothed noise parameters.

Filenames need to be read as follows.

Type number BFU730
Voltage 1p5=1.5V=Vce
10mA=10mA=Ic
S_N means noise parameters are included.

